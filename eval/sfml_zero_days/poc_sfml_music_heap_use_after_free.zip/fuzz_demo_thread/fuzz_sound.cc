#include <SFML/Audio/Music.hpp>
#include <SFML/Audio.hpp>

// Other 1st party headers
#include <SFML/System/Exception.hpp>
#include <SFML/System/FileInputStream.hpp>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <bits/stdc++.h>

std::ofstream ofs("output.log");

// fuzz_target.cc
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    sf::Music music;
    sf::SoundBuffer buffer;

    if (!music.openFromMemory((std::byte*) data, size)){
        return 0;
    } else {
        ofs << " " << music.getDuration().asSeconds() << " seconds" << '\n'
            << " " << music.getSampleRate() << " samples / sec" << '\n'
            << " " << music.getChannelCount() << " channels" << '\n' << std::flush;
        
        assert(!music.isLooping());
        assert(music.getStatus() == sf::Music::Status::Stopped);
        assert(music.getPlayingOffset() == sf::Time::Zero);

        music.play();
        while (music.getStatus() == sf::Music::Status::Stopped);
        assert(music.getStatus() == sf::Music::Status::Playing);
        music.pause();
        while (music.getStatus() == sf::Music::Status::Playing);
        assert(music.getStatus() == sf::Music::Status::Paused);
        music.play();
        while (music.getStatus() == sf::Music::Status::Paused);
        assert(music.getStatus() == sf::Music::Status::Playing);

        music.setLoopPoints({sf::seconds(1), sf::seconds(2)});

        sf::sleep(sf::milliseconds(1000));
    }

    if (!buffer.loadFromMemory((std::byte*) data, size)) {
        return 0;
    } else {
        ofs << " " << buffer.getDuration().asSeconds() << " seconds" << '\n'
            << " " << buffer.getSampleRate() << " samples / sec" << '\n'
            << " " << buffer.getChannelCount() << " channels" << '\n' << std::flush;

        sf::Sound sound(buffer);
        sound.play();

        while (sound.getStatus() == sf::Sound::Status::Playing) {
            // Leave some CPU time for other processes
            // sf::sleep(sf::milliseconds(100));

            assert(sound.getPlayingOffset().asMilliseconds() <= buffer.getDuration().asMilliseconds());
        }
    }
    return 0;
}


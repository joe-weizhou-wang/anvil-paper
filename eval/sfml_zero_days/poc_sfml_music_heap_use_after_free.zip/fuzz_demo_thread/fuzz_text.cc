#include <SFML/Graphics.hpp>
#include <iostream>
#include <stdio.h>
#include <vector>

// fuzz_target.cc
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    if (size == 0) {
        return 0;  // No data to process
    }
    std::vector<unsigned char> v(data, data + size);
    v.push_back('\0');  // Null-terminate the string
    const sf::Font font("../test/Graphics/tuffy.ttf");
    sf::Text text(font, (char*)v.data());

    // text.getString();
    // &text.getFont();
    // text.getCharacterSize();
    // text.getLetterSpacing();
    // text.getLineSpacing();
    // text.getStyle();
    // text.getFillColor();
    // text.getOutlineColor();
    // text.getOutlineThickness();
    text.findCharacterPos(0);
    // text.getLocalBounds();
    // text.getGlobalBounds();
    // text.setString("abcdefghijklmnopqrstuvwxyz");
    // assert(text.getString() == "abcdefghijklmnopqrstuvwxyz");
    // text.setCharacterSize(48);
    // assert(text.getCharacterSize() == 48);
    // text.setLineSpacing(42);
    // assert(text.getLineSpacing() == 42);
    // text.setLetterSpacing(15);
    // assert(text.getLetterSpacing() == 15);
    // text.setStyle(sf::Text::Bold | sf::Text::Italic);
    // assert(text.getStyle() == (sf::Text::Bold | sf::Text::Italic));
    // text.setFillColor(sf::Color::Red);
    // assert(text.getFillColor() == sf::Color::Red);
    // text.setOutlineColor(sf::Color::Green);
    // assert(text.getOutlineColor() == sf::Color::Green);
    // text.setOutlineThickness(3.14f);
    // assert(text.getOutlineThickness() == 3.14f);
    // text.setRotation(sf::degrees(180));
    // text.setPosition({120, 240});
    // assert(text.findCharacterPos(0) == sf::Vector2f(120, 240));


    return 0;  // Values other than 0 and -1 are reserved for future use.
}
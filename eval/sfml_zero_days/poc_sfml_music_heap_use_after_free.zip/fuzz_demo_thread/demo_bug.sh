pushd $(git rev-parse --show-toplevel)
    git stash
    rm -rf build
    git apply ./fuzz_demo_thread/enable_asan.patch
    cmake -B build -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang -DCMAKE_BUILD_TYPE=Debug -DSFML_BUILD_TEST_SUITE=ON -DSFML_ENABLE_SANITIZERS=ON
    cmake --build build --target all
popd

rm fuzz_sound *.o
rm -rf corpus
cp -r corpus_check corpus
clang++ -std=c++17 -g -c fuzz_sound.cc -I ../include -I /usr/include -fno-omit-frame-pointer -fno-sanitize-recover=all -fsanitize=address,fuzzer
clang++ fuzz_sound.o -g -o fuzz_sound ../build/lib/libsfml-audio-s-d.a ../build/lib/libsfml-system-s-d.a -lrt /usr/lib/x86_64-linux-gnu/libvorbisfile.so /usr/lib/x86_64-linux-gnu/libvorbisenc.so /usr/lib/x86_64-linux-gnu/libvorbis.so /usr/lib/x86_64-linux-gnu/libogg.so /usr/lib/x86_64-linux-gnu/libFLAC.so -lpthread -ldl -fno-omit-frame-pointer -fno-sanitize-recover=all -fsanitize=address,fuzzer

timeout 360 ./fuzz_sound -seed=33631507 corpus

pushd $(git rev-parse --show-toplevel)
    git reset --h
    git stash pop
popd
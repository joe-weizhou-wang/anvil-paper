#include <SFML/Audio/Music.hpp>
#include <SFML/Audio.hpp>

// Other 1st party headers
#include <SFML/System/Exception.hpp>
#include <SFML/System/FileInputStream.hpp>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <bits/stdc++.h>

// fuzz_target.cc
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    sf::Music music;

    if (music.openFromMemory((std::byte*) data, size))
        return 0;
    return -1;
}


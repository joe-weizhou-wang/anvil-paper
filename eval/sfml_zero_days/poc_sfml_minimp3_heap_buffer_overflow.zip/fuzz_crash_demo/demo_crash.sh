pushd $(git rev-parse --show-toplevel)
    git stash
    echo "Which version do you want to test?"
    select yn in "Fixed" "Buggy"; do
        case $yn in
            Fixed ) git apply ./fuzz_crash_demo/fix.patch; break;;
            Buggy ) break;;
        esac
    done

    rm -rf build
    # Use ASan intead of UBSan to detect memory errors
    git apply ./fuzz_crash_demo/enable_asan.patch
    cmake -B build -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang -DCMAKE_BUILD_TYPE=Debug -DSFML_BUILD_TEST_SUITE=ON -DSFML_ENABLE_SANITIZERS=ON
    cmake --build build --target all
popd

rm -rf fuzz_sound fuzz_sound.o
clang++ -std=c++17 -g -c fuzz_sound.cc -I ../include -I /usr/include -fno-omit-frame-pointer -fno-sanitize-recover=all -fsanitize=address,fuzzer
clang++ fuzz_sound.o -g -o fuzz_sound ../build/lib/libsfml-audio-s-d.a ../build/lib/libsfml-system-s-d.a -lrt /usr/lib/x86_64-linux-gnu/libvorbisfile.so /usr/lib/x86_64-linux-gnu/libvorbisenc.so /usr/lib/x86_64-linux-gnu/libvorbis.so /usr/lib/x86_64-linux-gnu/libogg.so /usr/lib/x86_64-linux-gnu/libFLAC.so -lpthread -ldl -fno-omit-frame-pointer -fno-sanitize-recover=all -fsanitize=address,fuzzer
./fuzz_sound ./crash-8c99c72c97586ff6cfa9ecf7a73540e25101bcb0

pushd $(git rev-parse --show-toplevel)
    git reset --h
    git stash pop
popd
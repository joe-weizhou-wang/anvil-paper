import parser_c as parser_c
import ast_parse as ast_parse
from cp_utils import write_file
import os
import sys

#command to dump the ast tree: clang-check --ast-dump $target_file --extra-arg="-fno-color-diagnostics"
dst_path =  "./../2024_cve_nonvul_funcs"
failed_file = []

def generate_ast_for_repo(repo_name, repo_path):
    Project_ins = parser_c.ProjectParser(repo_path, ".c")
    Project_ins.rec_extraction(Project_ins.repo_path, [".c", ".cc", ".h"])
    saved_path = dst_path + '/' + repo_name
    print(saved_path)
    for i in range(len(Project_ins.file_list)):
        example_file = Project_ins.file_list[i]
        #example_file = repo_path + '/poppler/Parser.cc'
        Project_ins.read_source_code(example_file)
        file_name = Project_ins.file_names[i]
        compound_stmt = extract_statement_line_numbers(Project_ins.file_source_code)
        func_info = dict()
        func_info['CompoundStmt'] = compound_stmt
        #command = "rm " + saved_path + "/ast"
        #os.system(command)
        saved_name = example_file.replace(Project_ins.repo_path, "")
        saved_name = saved_name.replace("/", "_")
        saved_name = saved_name.replace(".", "_")
        write_file(saved_path, "/" + saved_name + ".json", func_info)


def analyze_IR_for_repo(repo_name, file_name, repo_path):
    saved_path = dst_path + '/' + repo_name + "/"
    example_file = file_name
    saved_name = example_file.replace(repo_path, "")
    saved_name = saved_name.replace("/", "_")
    saved_name = saved_name.replace(".", "_")
    ast_example = ast_parse.ASTParser(example_file, ".c")
    ast_example.generate_ll_IR('.')
    try:
        ast_example.read_file("ir.ll")
    except:
        failed_file.append(example_file)
        return 0
    ast_example.parse_ir()
    ast_example.parse_function_dict()
    #print(ast_example.function_dict)
    write_file(saved_path, saved_name + ".json", ast_example.function_dict)
    #write_file(saved_path, "/location.json", ast_example.location_map)

def extract_statement_line_numbers(lines):
    stack = []
    statements = []
    line_number = 0

    # Concatenate lines to a single string while mapping indices to line numbers
    code = ''
    line_map = []
    for line in lines:
        line_number += 1
        start_index = len(code)
        code += line
        for i in range(start_index, len(code)):
            line_map.append(line_number)

    # Iterate over characters and their corresponding line numbers
    for index, char in enumerate(code):
        if char == '{':
            stack.append(index)  # Push the index of the opening brace
        elif char == '}':
            if stack:
                start = stack.pop()  # Pop the last unmatched opening brace
                end = index
                # Map start and end indices back to line numbers
                start_line = line_map[start]
                end_line = line_map[end]
                statements.append((start_line, end_line))

    return statements


if __name__ == "__main__":
    repo_name = sys.argv[1]
    #repo_path = "../magma/targets/" + repo_name + "/repo"
    repo_path = "../2024_cve_nonvul_funcs/files/"
    #Project_ins = parser_c.ProjectParser(repo_path, ".c")
    #Project_ins.rec_extraction(Project_ins.repo_path, ".c")
    generate_ast_for_repo(repo_name, repo_path)
    #generate_ast_for_repo("libpng", repo_path)
    #analyze_IR_for_repo("libpng", repo_path)
    saved_path = dst_path + '/' + repo_name + "/"
    write_file(saved_path, "failed_file.json", failed_file)

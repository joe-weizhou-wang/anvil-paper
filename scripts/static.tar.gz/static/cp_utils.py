import json
def write_file(folder, name, data):
     try:
         with open(folder + name, 'w') as f:
             json.dump(data, f, indent=4)
     except:
         print("failed to write to file")
         return False
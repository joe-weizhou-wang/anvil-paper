#!/usr/bin/env bash
mkdir -p ../data
repos=("libpng" "libsndfile" "libtiff" "libxml2" "lua" "openssl" "php" "poppler" "sqlite3")
#repos=("poppler")
for repo_ins in "${repos[@]}"; do
    rm -r ../data/$repo_ins/*
    mkdir -p ../data/$repo_ins
    echo "Extracting $repo_ins"
    python3 main.py $repo_ins
done

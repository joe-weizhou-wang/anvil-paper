import sys
import os
import re

class ProjectParser:
    def __init__(self, repo_path, type) -> None:
        self.repo_path = repo_path
        self.type = type
        self.file_list = []
        self.file_names = []
        self.file_source_code = []

    def rec_extraction(self, dir_name, type):
        for file in os.listdir(dir_name):
            path = dir_name + '/' + file
            if file.endswith(type[0]) or file.endswith(type[1]) or file.endswith(type[2]):
                self.file_list.append(path)
                self.file_names.append(file)
            elif os.path.isdir(path):
                self.rec_extraction(path, type)

    def read_source_code(self, file_path):
        with open(file_path, 'r', errors='ignore') as file:
            self.file_source_code = file.readlines()

    def check_function_name_in_source_code(self, func_name):
        for line in self.file_source_code:
            if func_name in line:
                return True
        return False
    
    def read_file(self, file_path):
        with open(file_path, 'r', errors='ignore') as file:
            return file.read()
    
    def extract_line_number(self, result):
        tmp_result = []
        for item in result:
            new_item = re.search(r':.*?:', item)
            if new_item:
                new_item = new_item.group(0).replace(':', '')
                tmp_result.append(int(new_item))
        return tmp_result
    
    def load_ast_info(self, ast_file, file_path):
        func_info = dict()
        func_info['CompoundStmt'] = []
        func_info['DeclStmt'] = []
        flag = 0
        with open(ast_file, 'r', errors='ignore') as file:
            lines_ast = file.readlines()
        for line in lines_ast:
            line = line.strip()
            if 'FunctionDecl' in line:
                func_name = self.extract_function_name(line)
                if self.check_function_name_in_source_code(func_name):
                    flag = 1
                else:
                    flag = 0
            if ('CompoundStmt' in line or 'FunctionDecl' in line) and flag == 1:
                result = re.search(r'<.*?>', line)
                result = result.group(0).replace('<', '').replace('>', '')
                result = result.split(' ')
                if len(result) <= 1:
                    continue
                if not(result[0].startswith('line') or result[0].startswith(file_path)):
                    continue
                if not(result[1].startswith('line') or result[1].startswith(file_path)):
                    continue
                result = self.extract_line_number(result)
                func_info['CompoundStmt'].append(result)
            if 'DeclStmt' in line and flag == 1:
                result = re.search(r'<.*?>', line)
                result = result.group(0).replace('<', '').replace('>', '')
                result = result.split(' ')
                if not(result[0].startswith('line') or result[0].startswith(file_path)):
                    continue
                result = self.extract_line_number([result[0]])
                func_info['DeclStmt'].append(result[0]) 

        return func_info
    
    def generate_ast(self, file_path, dst_path):
        command = "clang -Xclang -ast-dump -fsyntax-only -fno-color-diagnostics " + file_path + ' > ' + dst_path + '/ast'
        os.system(command)

    def generate_ll_IR(self, file_path, dst_path):
        command = "clang -O0 -g -S -emit-llvm " + file_path + ' -o ' + dst_path + '/ir.ll'
        print(command)
        os.system(command)

    def extract_function_name(self, line=''):
        line_half = line.split("'")[0].strip()
        name = line_half.split(' ')[-1]
        #print(name)
        #print(line)
        name = name.replace('MAGMA_', '')
        return name

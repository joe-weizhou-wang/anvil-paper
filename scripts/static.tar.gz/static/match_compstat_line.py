import json

def extract_compound_statement_no(folder, file, line_no = 80, level = 1):
    extracted_comp_stat = []
    tmp_file_components  = file.split('repo/')
    #project_name = tmp_file_components[0].split('targets/')[1]
    project_name = ''
    #tmp_name = tmp_file_components[1]
    target_dir = folder +  project_name + '/'
    #file_name = tmp_name.replace('/', '_').replace('.', '_')
    file_name = file.replace('/', '_').replace('.', '_')
    target_file = target_dir + project_name + '_' + file_name + '.json'
    try:
        with open(target_file) as json_file:
            contents = json_file.read()
    except:
        print("Error in reading json file 2")
        return None
    compound_statement_no = json.loads(contents)['CompoundStmt']
    for interval in compound_statement_no:
        if line_no >= interval[0] and line_no < interval[1]:
            if not check_whether_list_is_in_list(interval, extracted_comp_stat):
                extracted_comp_stat.append(interval)
    return sort_by_difference(extracted_comp_stat)

def sort_by_difference(lst):
    return sorted(lst, key=lambda x: x[1] - x[0])

def read_json(file_path):
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        return data
    except:
        print("Error in reading json file")
        return None

def write_file(path, file_name, data):
    with open(path + file_name, 'w') as f:
        json.dump(data, f, indent=4)
    return

sample_files = read_json('../2024_cve_nonvul_funcs/2024_CVE_nonvul_functions.json')
print(len(sample_files))

def check_whether_list_is_in_list(lst1, lst2):
    for elem in lst2:
        if lst1[0] == elem[0] and lst1[1] == elem[1]:
            return True

for file_name in sample_files:
    #print(file_name)
    file_info = sample_files[file_name]
    folder_bug = '../data-bug/'
    folder_fix = '../data-fix/'
    folder_files = '../2024_cve_nonvul_funcs/results/'
    cve_lines = sample_files[file_name]["cve_lines"]
    """  file_info['cve_comp_stat'] = dict()
    for line_no in cve_lines:
        if type(line_no) is str:
            line_no_lst = [line_no]
        else:
            line_no_lst = line_no
        for line in line_no_lst:
            extracted_comp_stat = extract_compound_statement_no(folder_files, file_name, int(line))
            if extracted_comp_stat is None:
                extracted_comp_stat = "do not support current file type for compound statement extraction"
                break
            file_info['cve_comp_stat'][line] = extracted_comp_stat """
    sample_lines = sample_files[file_name]["sampled_lines"]
    file_info['sampled_comp_stat'] = dict()
    for line_no in sample_lines:
        if type(line_no) is str:
            line_no_lst = [line_no]
        else:
            line_no_lst = line_no
        for line in line_no_lst:
            extracted_comp_stat = extract_compound_statement_no(folder_files, file_name, int(line))
            if extracted_comp_stat is None:
                extracted_comp_stat = "do not support current file type for compound statement extraction"
                break
            file_info['sampled_comp_stat'][line] = extracted_comp_stat
    """patch_lines = sample_files[file_name]["patch_lines"]
    file_info['patch_comp_stat'] = dict()
    for line_no in patch_lines:
        if type(line_no) is str:
            line_no_lst = [line_no]
        else:
            line_no_lst = line_no
        for line in line_no_lst:
            extracted_comp_stat = extract_compound_statement_no(folder_fix, file_name, int(line))
            if extracted_comp_stat is None:
                extracted_comp_stat = "do not support current file type for compound statement extraction"
                break
            file_info['patch_comp_stat'][line] = extracted_comp_stat """
    sample_files[file_name] = file_info

write_file('../2024_cve_nonvul_funcs/', '2024_CVE_nonvul_functions_new.json', sample_files)
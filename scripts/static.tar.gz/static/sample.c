#include <stdio.h>

int main()
{
    int i;
    int inbuf[100];
    int outbuf[100];

    for(i = 0; i < 100; ++i)        
        inbuf[i] ^= outbuf[i];

    inbuf[1] += 402;
    inbuf[6] += 107;
    inbuf[97] += 231;

    for(i = 0; i < 100; ++i)       
    {
        inbuf[i] += outbuf[i];                 
    }
    inbuf[47] += 312;  
    //print-statements 
    for (i=0;i<100;i++) {
        printf("inbuf[%d] = %d\n",i,inbuf[i]);              
    }
                 
    return 0;
}

clang -O0 -g -S -emit-llvm sample.c -o sample.ll
#DILocation in .ll file

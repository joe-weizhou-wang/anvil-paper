import sys
import os
import re

class ASTParser:
    def __init__(self, file_path, type) -> None:
        self.file_path = file_path
        self.ast_file = []
        self.function_dict = dict()
        self.location_map = []
    
    def read_file(self, file_path):
        with open(file_path, 'r') as file:
            self.ast_file = file.readlines()

    def generate_ll_IR(self, dst_path):
        command = "clang -O0 -g -S -emit-llvm -Wno-error -ferror-limit=0 " + self.file_path + ' -o ' + dst_path + '/ir.ll'
        os.system(command)
    
    def extract_DILocation(self, line=''):
        components = line.split('=')
        if len(components) < 2:
            return ''
        BB_line_num = components[0].strip()
        line_num = components[1].strip()
        BB_line_num = BB_line_num.replace('!', '')
        BB_line_num = int(BB_line_num)
        line_num = re.search(r'line:.*?,', line_num)
        return [BB_line_num, int(line_num.group(0).replace('line:', '').replace(',', ''))]
    
    def extract_function_name(self, line=''):
        result = re.search(r'@.*?\(', line)
        if result:
            return result.group(0).replace('@', '').replace('(', '')

    def parse_ir(self):
        name = ''
        for line in self.ast_file:
            line = line.strip()
            if line is None or type(line) is not str:
                continue
            if 'DILocation' in line:
                location = self.extract_DILocation(line)
                self.location_map.append(location)
            if line.startswith('define'):
                name = self.extract_function_name(line)
                self.function_dict[name] = []
            if len(line) > 0 and line[0] == '}':
                self.function_dict[name].append(line)
                name = ''
            if len(name) > 0:
                self.function_dict[name].append(line)
    
    def parse_function_dict(self):
        splitter = ""
        tmp_function_dict = dict()
        for key, value in self.function_dict.items():
            result = []
            tmp_list = []
            for line in value:
                if splitter == line:
                    result.append(tmp_list)
                    tmp_list = []
                else:
                    tmp_list.append(line)
            self.function_dict[key] = result
        for key, function in self.function_dict.items():
            tmp_function_dict[key] = dict()
            for BB in function:
                BB_lines = []
                BB_obj = dict()
                #extract the identifier for basic block and also its predecessors
                if 'define' in BB[0]:
                    BB_name = 'define'
                    preds = []
                else:
                    BB_name = int(BB[0].split(':')[0])
                    if len(BB[0].split('=')) > 1:
                        preds = BB[0].split('=')[1].split(',')
                    else:
                        preds = []
                #save the raw content of basic block
                BB_obj['BB_content'] = BB
                #save the predecessors of basic block
                BB_obj['preds'] = [int(pred.strip().replace('%', '')) for pred in preds]
                #extract the line numbers of each statement in the basic block
                for line in BB:
                    if '!dbg' in line:
                        line_num = line.split('!dbg')[1].strip()
                        line_num = line_num.replace('!', '').replace(' ', '').replace('{', '')
                        if 'llvm.loop' in line_num:
                            orig_line_num = line_num.split(',')[0]
                            loop_num = line_num.split(',')[1]
                            BB_lines.append(int(orig_line_num))
                            BB_lines.append(int(loop_num.replace('llvm.loop', '')))
                        else:
                            BB_lines.append(int(line_num))
                BB_lines = list(set(BB_lines))
                BB_obj['BB_lines'] = BB_lines
                BB_obj['source_code_lines'] = []
                #map the basic block line numbers back to the source code line numbers:
                for map_pair in self.location_map:
                    for BB_line in BB_lines:
                        if map_pair[0] == BB_line:
                            BB_obj['source_code_lines'].append(map_pair[1])
                            break
                BB_obj['source_code_lines'] = list(set(BB_obj['source_code_lines']))
                tmp_function_dict[key][BB_name] = BB_obj
        self.function_dict = tmp_function_dict           
            